#include <iostream>
#include <string>
using namespace std;

class Hotel {
private:
    struct Node {
        int id;
        int date;
        string name;
        string roomtype;
        bool reserved;
        Node* next;
    };

public:
    Node* head = NULL;

    void insert();
    void menu();
    void update();
    void search();
    void del();
    void sort();
    void show();
    void reserve();
    void checkIn();
    void checkOut();
    void assignRoom();
    void inventory();
};

void Hotel::menu() {
    int choice;
    cout << "\n\tWelcome to the Hotel Management System\n" << endl;
    cout << "\t______________Hotel Management System________________" << endl;
    cout << "\n\t\tMenu:\n";
    cout << "1. Book new room" << endl;
    cout << "2. Search room" << endl;
    cout << "3. Update room" << endl;
    cout << "4. Delete room" << endl;
    cout << "5. Show room record" << endl;
    cout << "6. Reserve a room" << endl;
    cout << "7. Check-in a guest" << endl;
    cout << "8. Check-out a guest" << endl;
    cout << "9. Assign room to a guest" << endl;
    cout << "10. Inventory management" << endl;
    cout << "11. Exit" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case 1:
            insert();
            break;
        case 2:
            search();
            break;
        case 3:
            update();
            break;
        case 4:
            del();
            break;
        case 5:
            sort();
            show();
            break;
        case 6:
            reserve();
            break;
        case 7:
            checkIn();
            break;
        case 8:
            checkOut();
            break;
        case 9:
            assignRoom();
            break;
        case 10:
            inventory();
            break;
        case 11:
            cout << "\nExiting the program. Goodbye!\n";
            return;
        default:
            cout << "\nInvalid choice. Please try again.\n";
            break;
    }

    menu();
}

void Hotel::insert() {
    cout << "\n____Hotel Management System____" << endl;
    Node* newNode = new Node;

    cout << "\nEnter room id: ";
    cin >> newNode->id;
    cout << "Enter customer name: ";
    cin.ignore();
    getline(cin, newNode->name);
    cout << "Enter allocated date: ";
    cin >> newNode->date;
    cout << "Enter room type (single/double/twin): ";
    cin >> newNode->roomtype;
    newNode->reserved = false;

    if (head == NULL) {
        head = newNode;
        newNode->next = NULL;
    } else {
        Node* ptr = head;
        while (ptr->next != NULL) {
            ptr = ptr->next;
        }
        ptr->next = newNode;
        newNode->next = NULL;
    }
    cout << "\n\n\t\tNew room inserted";
}

void Hotel::search() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                cout << "\n\nRoom id: " << ptr->id;
                cout << "\nCustomer name: " << ptr->name;
                cout << "\nRoom allocated date: " << ptr->date;
                cout << "\nRoom type: " << ptr->roomtype;
                cout << "\nRoom " << (ptr->reserved ? "is reserved" : "is not reserved");
                found = true;
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::update() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                cout << "\nEnter new customer name: ";
                cin.ignore();
                getline(cin, ptr->name);
                cout << "Enter new allocated date: ";
                cin >> ptr->date;
                cout << "Enter new room type (single/double/twin): ";
                cin >> ptr->roomtype;
                found = true;
                cout << "\n\t\tUpdated record successfully";
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::del() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        if (id == head->id) {
            Node* ptr = head;
            head = head->next;
            delete ptr;
            cout << "\nDelete room record successful";
        } else {
            Node* pre = head;
            Node* ptr = head;
            bool found = false;
            while (ptr != NULL) {
                if (id == ptr->id) {
                    pre->next = ptr->next;
                    delete ptr;
                    cout << "\nDelete room record successful";
                    found = true;
                    break;
                }
                pre = ptr;
                ptr = ptr->next;
            }
            if (!found) {
                cout << "\nRoom with id " << id << " does not exist.";
            }
        }
    }
}

void Hotel::sort() {
    if (head == NULL) {
        cout << "\n\nLinked list is empty" << endl;
        return;
    }

    int count = 0;
    Node* ptr = head;
    while (ptr != NULL) {
        count++;
        ptr = ptr->next;
    }

    for (int i = 1; i <= count; i++) {
        ptr = head;
        for (int j = 1; j < count; j++) {
            if (ptr->id > ptr->next->id) {
                int id = ptr->id;
                string name = ptr->name;
                int date = ptr->date;
                string roomtype = ptr->roomtype;
                bool reserved = ptr->reserved;
                ptr->id = ptr->next->id;
                ptr->name = ptr->next->name;
                ptr->date = ptr->next->date;
                ptr->roomtype = ptr->next->roomtype;
                ptr->reserved = ptr->next->reserved;
                ptr->next->id = id;
                ptr->next->name = name;
                ptr->next->date = date;
                ptr->next->roomtype = roomtype;
                ptr->next->reserved = reserved;
            }
            ptr = ptr->next;
        }
    }
}

void Hotel::show() {
    cout << "\n____Hotel Management System____" << endl;
    Node* ptr = head;
    if (ptr == NULL) {
        cout << "\nLinked list is empty" << endl;
    } else {
        while (ptr != NULL) {
            cout << "\nRoom id: " << ptr->id;
            cout << "\nCustomer name: " << ptr->name;
            cout << "\nRoom allocated date: " << ptr->date;
            cout << "\nRoom type: " << ptr->roomtype;
            cout << "\nRoom " << (ptr->reserved ? "is reserved" : "is not reserved");
            cout << endl;
            ptr = ptr->next;
        }
    }
}

void Hotel::reserve() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                if (ptr->reserved) {
                    cout << "\nRoom is already reserved";
                } else {
                    ptr->reserved = true;
                    cout << "\nRoom with id " << id << " reserved successfully";
                }
                found = true;
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::checkIn() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                if (ptr->reserved) {
                    cout << "\nGuest checked-in successfully";
                    ptr->reserved = false;
                } else {
                    cout << "\nRoom with id " << id << " is not reserved.";
                }
                found = true;
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::checkOut() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                cout << "\nGuest checked-out successfully";
                ptr->reserved = false;
                found = true;
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::assignRoom() {
    cout << "\n____Hotel Management System____" << endl;
    int id;

    if (head == NULL) {
        cout << "\n\nLinked list is empty";
    } else {
        cout << "\nEnter room id: ";
        cin >> id;
        Node* ptr = head;
        bool found = false;
        while (ptr != NULL) {
            if (id == ptr->id) {
                if (ptr->reserved) {
                    cout << "\nRoom with id " << id << " is already reserved.";
                } else {
                    cout << "\nEnter customer name: ";
                    cin.ignore();
                    getline(cin, ptr->name);
                    cout << "Enter allocated date: ";
                    cin >> ptr->date;
                    cout << "Enter room type (single/double/twin): ";
                    cin >> ptr->roomtype;
                    ptr->reserved = true;
                    cout << "\nRoom assigned to guest successfully";
                }
                found = true;
            }
            ptr = ptr->next;
        }
        if (!found) {
            cout << "\nRoom with id " << id << " does not exist.";
        }
    }
}

void Hotel::inventory() {
    cout << "\n____Hotel Management System____" << endl;
    int count = 0;
    Node* ptr = head;
    while (ptr != NULL) {
        count++;
        ptr = ptr->next;
    }
    cout << "\nTotal number of rooms: " << count << endl;
}

int main() {
    Hotel hotel;
    hotel.menu();
    return 0;
}
